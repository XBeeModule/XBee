#ifndef __SPI_1_H
#define __SPI_1_H

//#include <stm32f4xx_gpio.h>
//#include <stm32f4xx_rcc.h>
//#include <stm32f4xx_spi.h>
//#include <stm32f4_discovery.h>

void spi1_init();
uint8_t spi1_send(uint8_t data);
uint16_t spi1_receve();


#define TFT_CS_LOW GPIO_ResetBits(GPIOA, GPIO_Pin_4);
#define TFT_CS_HIGH GPIO_SetBits(GPIOA, GPIO_Pin_4); // cs

#endif /* __SPI_1_H */
